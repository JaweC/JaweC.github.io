﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MTA_98_361
{
    class Program
    {
        static void Main(string[] args)
        {
            string helloWorld = "Hello, world";
            char exclamationMark = '!';
            

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(helloWorld + "{0}", exclamationMark);
            Console.ReadKey();
            SomethingWentWrong("?");
            
        }

        static void SomethingWentWrong(string error)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Something went wrong: {0}", error);
            Console.ReadKey();
        }
    }
}
