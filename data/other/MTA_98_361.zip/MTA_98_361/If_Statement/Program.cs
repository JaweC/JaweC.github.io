﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace If_Statement
{
    class Program
    {
        static void Main(string[] args)
        {
            int number1 = 10;
            int number2 = 20;
            
            if (number2 > number1)
            {
                Console.WriteLine("number2 is greater than number1");
                Console.ReadKey();
            }
        }
    }
}
