﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DaysOfTheWeek
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welkom bij de menu applicatie!");
            int choice;
            string input;

            //Als je een while wilt gebruiken maar ten minste één keer wilt uitvoeren.
                do
                {
                    Console.WriteLine("Voer een dagnummer in (bijv. maandag = 1, zondag = 7:");
                    input = Console.ReadLine();
                    bool result = int.TryParse(input, out choice);


                }
                //Als je niet weet hoevaak je iets wilt uitvoeren.
                while (choice <1 || choice > 7);


                switch (choice)
                {
                    

                    case 1: Console.WriteLine("Vandaag is het maandag");
                        break;

                    case 2: Console.WriteLine("Vandaag is het dindag");
                        break;

                    case 3: Console.WriteLine("Vandaag is het woensdag");
                        break;

                    case 4: Console.WriteLine("Vandaag is het donderdag");
                        break;

                    case 5: Console.WriteLine("Vandaag is het vrijdag");
                        break;

                    case 6: Console.WriteLine("Vandaag is het zaterdag");
                        break;

                    default: Console.WriteLine("Vandaag is het zondag");
                        break;  
                }


                Console.ReadKey();

            //if (choice == 1)
            //{
            //    Console.WriteLine("Vandaag is het maandag");
            //}

            //else if (choice == 2)
            //{
            //    Console.WriteLine("Vandaag is het dinsdag");
            //}

            //else if (choice == 3)
            //{
            //    Console.WriteLine("Vandaag is het woensdag");
            //}
            //else if (choice == 4)
            //{
            //    Console.WriteLine("Vandaag is het donderdag");
            //}
            //else if (choice == 5)
            //{
            //    Console.WriteLine("Vandaag is het vrijdag");
            //}
            //else if (choice == 6)
            //{
            //    Console.WriteLine("Vandaag is het zaterdag");
            //}
            //else if (choice == 7)
            //{
            //    Console.WriteLine("Vandaag is het zondag");
            //}
            
           
        }
    }
}
