﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rectangle
{

    class Polygon
    {
        //public double Length { get; protected set; }
        //public double Width { get; protected set; }
        //abstract public double GetArea();
        public virtual void Draw()
        {
            Console.WriteLine("Drawing: Polygon");
            Console.ReadKey();
        }
    }
    class Rectangle: Polygon, IComparable
    {

        public double Length { get; set; }
        public double Width { get; set; }
        public override void Draw()
        {
            Console.WriteLine("Drawing: Rectangle");
            Console.ReadKey();
        }


        public double GetArea()
        {
            return Width * Length;
        }

        public int CompareTo(object obj)
        {
            if (obj == null)
                return 1;

            if (!(obj is Rectangle))
                throw new ArgumentException();

            Rectangle target = (Rectangle)obj;
            double diff = this.GetArea() - target.GetArea();

            if (diff == 0)
                return 0;
            else if (diff > 0)
                return 1;
            else return -1;
        }
        //public Rectangle(double length, double width)
        //{
        //    Length = length;
        //    Width = width;
        //}


        //public static string ShapeName
        //{
        //    get { return "Rectangle"; }
        //}

        //public double Length { get; set; }
        //public double Width { get; set; }
        //public double GetArea()
        //{
        //    return this.Length * this.Width;
        //}
        //public event EventHandler Changed;
        //private double length;
        //private double width;
        //public double Length
        //{
        //    get
        //    {
        //        return length;
        //    }
        //    set
        //    {
               
        //            length = value;
        //            Changed(this, EventArgs.Empty);
        //    }
        //}
        //public double Width
        //{
        //    get
        //    {
        //        return width;
        //    }
        //    set
        //    {
        //        if (value > 0.0)
        //            width = value;
        //    }
        //}
        


        //public double GetArea()
        //{
        //    return length * width;
        //}
    }


    class Triangle : Polygon
    {

        public new void Draw()
        {
            Console.WriteLine("Drawing: Triangle");
            Console.ReadKey();
        }
    }

    struct Point
    {
        public Double X, Y;
    }
    
    class Program
    {
        static void Main(string[] args)
        {
            Rectangle rect1 = new Rectangle
            {
                Length = 10,
                Width = 20
            };

            Rectangle rect2 = new Rectangle
            {
                Length = 100,
                Width = 200
            };
            Console.WriteLine(rect1.CompareTo(rect2));
            Console.ReadKey();

            //Triangle t = new Triangle();
            //t.Draw();
            //Polygon p = t;
            //p.Draw();

            //List<Polygon> polygons = new List<Polygon>();
            //polygons.Add(new Polygon());
            //polygons.Add(new Rectangle());
            //polygons.Add(new Triangle());

            //foreach (Polygon p in polygons)
            //{
            //    p.Draw();
            //}

            //Rectangle rect = new Rectangle(10, 20);
            //Console.WriteLine("Width={0}, Length={1}, Area = {2}", rect.Width, rect.Length, rect.GetArea());
            //Console.ReadKey();

            //Point p1 = new Point();
            //p1.X = 10;
            //p1.Y = 20;
            //Point p2 = p1;
            //p2.X = 100;
            //Console.WriteLine("p1.X = {0}", p1.X);


            //Rectangle rect2 = rect1;
            //rect2.Length = 100.0;
            //Console.WriteLine("rect1.Length = {0}", rect1.Length);
            //Console.ReadKey();
            //Rectangle rect = new Rectangle
            //{
            //    Length = 10.0,
            //    Width = 20.0
            //};

            //Console.WriteLine("Shape Name: {0}, Area: {1}", Rectangle.ShapeName, rect.GetArea());
            //Console.ReadKey();

            //Rectangle r = new Rectangle();
            //r.Changed += new EventHandler(r_Changed);
            //r.Length = 10;

            //Rectangle rect = new Rectangle();
            //rect.Length = 10.0;
            //rect.Width = 20.0;
            //double area = rect.GetArea();
            //Console.WriteLine("Area of Rectangle: {0}", area);
            //Console.ReadKey();
        }

        //static void r_Changed(object sender, EventArgs e)
        //{
        //    Rectangle r = (Rectangle)sender;
        //    Console.WriteLine("Value Changed: Length = {0}", r.Length);
        //    Console.ReadKey();
        //}
    }
}
