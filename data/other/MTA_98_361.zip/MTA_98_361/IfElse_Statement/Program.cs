﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IfElse_Statement
{
    class Program
    {
        static void Main(string[] args)
        {
            TestIfElse(10);
        }

        public static void TestIfElse(int n)
        {
            if (n < 10)
            {
                Console.WriteLine("n is less than 10");
                Console.ReadKey();
            }
            else if (n < 20)
            {
                Console.WriteLine("n is less than 20");
                Console.ReadKey();
            }
            else if (n < 30)
            {
                Console.WriteLine("n is less than 30");
                Console.ReadKey();
            }
            else
            {
                Console.WriteLine("n is greater than or equal to 30");
                Console.ReadKey();
            }
        }
    }
}
