﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Loops2
{
    class Program
    {
        static void Main(string[] args)
        {
            string input;
            int choice;


            do
            {
                Console.WriteLine("Voer een getal in");
                input = Console.ReadLine();

            } while (!int.TryParse(input, out choice));

            if (choice > 10)
            {
                for (int i = 0; i < choice + 10; i++)
                {
                    Console.WriteLine(i); 
                }
            }
            Console.ReadKey();
        }
    }
}
